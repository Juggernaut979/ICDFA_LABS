**Name:** Adeleke Oluwpelumi Faruq  
**Registration Number:** C11/26/FCDF/17167  

- I was able to understand standard text streams (stdin, stdout, stderr), redirect standard output (`>`) and append output (`>>`) to files, redirect standard error (`2>`) separately or combine streams (`2>&1`), discard unwanted output using `/dev/null`, build multi-stage command pipelines using the pipe operator (`|`), and use `tee` to simultaneously display and save output.

- I was able to monitor and manage Linux processes using `ps` and `ps aux`, run commands in the background using `&`, control job execution using `jobs`, `fg`, `bg`, and `Ctrl+Z`, terminate processes safely with `kill` or forcibly with `kill -9`, inspect real-time resource utilization with `top`, adjust execution priorities with `nice`, and visualize process trees using `pstree`.

- I was able to set up test directory structures for archiving, create standard uncompressed archives with `tar -cvf`, view archive contents without extraction (`tar -tvf`), compress archives using `gzip` and `bzip2`, extract files to standard or specific destination directories (`-C`), extract specific individual files from an archive, create incremental backups based on modification times, and compare archive file sizes.

- I was able to read and interpret symbolic Linux permissions (rwx), calculate and apply numeric (octal) permission values, modify permissions symbolically and numerically using `chmod`, alter user and group ownership with `chown` and `chgrp`, apply permissions recursively across subdirectories (`-R`), configure default file creation masks with `umask`, and apply special permissions including the `setuid` bit and sticky bit (`+t`).

### Key Challenges
The major challenge I faced was remembering the correct flags for tar compression formats (`-z` for gzip vs `-j` for bzip2), and ensuring I used `>>` instead of `>` so I didn't accidentally overwrite existing file contents during output redirection.

### Key Commands
`echo`, `cat`, `sort`, `uniq`, `ps`, `kill`, `tar`, `gzip`, `chmod`, `chown`, `chgrp`
